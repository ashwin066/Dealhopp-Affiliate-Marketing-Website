  <!--
    - FOOTER
  -->
  <div style="
    display: flex;
    align-items: baseline;
    justify-content: center;">
      <h6 style="color:grey;">Made with <i class="fa fa-heart heart text-danger"></i>
          &
          <i class="fas fa-coffee heart text-danger"></i> in&nbsp;INDIA
      </h6>
      <!-- <a title="View my instagram" href="https://www.instagram.com/ashwin_r66/" target="_blank"
            style="font-size: 1rem !important;text-transform:capitalize !important" class="footer-category-title">Ashwin
            R</a> -->

  </div>
  <footer>
      <div class="footer-category">
          <div class="container">
              <h2 class="footer-category-title">Brand directory</h2>
              <div class="footer-category-box">
                  <h3 class="category-box-title mb-0">Explore :</h3>
                  <a href="index.php" class="footer-category-link">Live Deals</a>
                  <a href="stores.php" class="footer-category-link">Our Partner Stores</a>
                  <a href="privacy_policy.php" class="footer-category-link">Privacy policy</a>
                  <a href="terms_of_use.php" class="footer-category-link">Terms of use</a>
                  <a href="disclaimer.php" class="footer-category-link">Disclaimer</a>

              </div>


          </div>
      </div>





      <div class="footer-bottom">
          <div class="container">
              <!-- <img src="./assets/images/payment.png" alt="payment method" class="payment-img"> -->
              <p class="copyright"> Copyright &copy;
                  <a href="https://www.instagram.com/ashwin_r66/">Dealhopp</a> all rights reserved.
              </p>
          </div>
      </div>
  </footer>